import React, { Component } from 'react';
import { Card, CardBody, CardHeader, FormGroup, Label, Col, Input, Form, Button } from 'reactstrap';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import axios from 'axios';
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { connect } from 'react-redux';
import { getFacultyList } from '../../redux/Admin/AdminAction';
import { getFaculty } from '../../redux/Admin/AdminAction';

am4core.useTheme(am4themes_animated);

class AddSection extends Component {


    constructor(props) {
        super(props)
        this.state = {
            heading: '',
            deadline: '',
            marking: '',
            compulsory: 'NO',
            faculty: ''
        }

        this.onPost = this.onPost.bind(this)

        console.log("getFacultyList", this.props)
    }

    componentDidMount() {
      let chart = am4core.create("chartdiv", am4charts.XYChart);

      chart.data = [{
        "synopsisStatus": "AI",
        "count": 54
      },{
        "synopsisStatus": "Block Chain",
        "count": 13
      },{
        "synopsisStatus": "Networks",
        "count": 8
      },{
        "synopsisStatus": "Cloud Computing",
        "count": 4
      }
      ,{
        "synopsisStatus": "Distributed Databases",
        "count": 3
      }
      ,{
        "synopsisStatus": "NLP",
        "count": 1
      }];

      // Create axes

      var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "synopsisStatus";
      categoryAxis.renderer.grid.template.location = 0;
      categoryAxis.renderer.minGridDistance = 30;

      categoryAxis.renderer.labels.template.adapter.add("dy", function(dy, target) {
        if (target.dataItem && target.dataItem.index & 2 == 2) {
          return dy + 25;
        }
        return dy;
      });

      var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

      // Create series
      var series = chart.series.push(new am4charts.ColumnSeries());
      series.dataFields.valueY = "count";
      series.dataFields.categoryX = "synopsisStatus";
      series.name = "count";
      series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
      series.columns.template.fillOpacity = .8;

      var columnTemplate = series.columns.template;
      columnTemplate.strokeWidth = 0;
      columnTemplate.strokeOpacity = 1;

      columnTemplate.fill = am4core.color("#4591c3");
      columnTemplate.adapter.add("fill", function(fill, target) {
        if (target.dataItem && (target.dataItem.valueY < 5)) {
          return am4core.color("#B00100");
        }else if (target.dataItem && (target.dataItem.valueY < 10)) {
          return am4core.color("#008000");
        }
        else if (target.dataItem && (target.dataItem.valueY < 20)) {
          return am4core.color("#3c3cc7");
        }
        else if (target.dataItem && (target.dataItem.valueY < 30)) {
          return am4core.color("#9aa531");
        }
        else if (target.dataItem && (target.dataItem.valueY < 50)) {
          return am4core.color("#2196f3");
        }
        else if (target.dataItem && (target.dataItem.valueY < 100)) {
          return am4core.color("#c450d8");
        }
        else {
          return fill;
        }
      });

      this.chart = chart;
    }

      componentWillMount(){

        if (this.chart) {
          this.chart.dispose();
        }
      }

    onPost(event) {



        event.preventDefault();




        axios.post('/api/synopsis/register', {
            title: this.state.heading,
            supervisorId: this.props.facultyList.facultyList[+this.state.faculty],
            studentId: -1,
            deadline: this.state.deadline,
            marking: this.state.marking,
            compulsory: this.state.compulsory
        }).then((res) => {

            alert("Posted Assignment")

        }).catch((err) => {
            console.log(err)
        })
    }

    render() {
        return (
            <div>
                <Card style={{ width: '80%', marginLeft: "5%", marginTop: '2%', }}>
                    <CardHeader style={{ textAlign: 'center', backgroundColor: '#647280' }}>
                        <h2 style={{ marginLeft: '2%' }}>Add Section</h2>
                    </CardHeader>
                    <CardBody>

                        <Form onSubmit={this.onPost} className="form-horizontal">
                            <FormGroup row>
                                <Col md="3">
                                    <Label htmlFor="text-input">Heading</Label>
                                </Col>
                                <Col xs="12" md="9">
                                    <Input type="text" value={this.state.heading} id="fname" name="fname" placeholder="Heading" onChange={(event) => this.setState({ ...this.state, heading: event.target.value })} />
                                </Col>
                            </FormGroup>
                            <FormGroup row>
                                <Col md="3">
                                    <Label htmlFor="text-input">Deadline</Label>
                                </Col>
                                <Col xs="12" md="9">
                                    <Input type="datetime-local" value={this.state.deadline} id="lname" name="lname" placeholder="Deadline" onChange={(event) => this.setState({ ...this.state, deadline: event.target.value })} />
                                </Col>
                            </FormGroup>
                            <FormGroup row>
                                <Col md="3">
                                    <Label htmlFor="text-input">Marking Scheme</Label>
                                </Col>
                                <Col xs="12" md="9">
                                    <Input type="text" value={this.state.marking} id="fathernam" name="fathernam" placeholder="Marking Scheme" onChange={(event) => this.setState({ ...this.state, marking: event.target.value })} />
                                </Col>
                            </FormGroup>
                            <FormGroup row>
                                <Col md="3">
                                    <Label htmlFor="text-input">Compulsory</Label>
                                </Col>
                                <Col xs="12" md="9">
                                    <Input onChange={(event) => this.setState({ ...this.state, compulsory: event.target.value })} type="select" name="selectMulti" id="exampleSelectMulti">
                                        <option>NO</option>
                                        <option>YES</option>
                                    </Input>
                                </Col>
                            </FormGroup>

                            <FormGroup row>
                                <Col md="3">
                                    <Label htmlFor="text-input">Alot Supervisor</Label>
                                </Col>
                                <Col xs="12" md="9">
                                    <Input type="select" onChange={(event) => this.setState({ ...this.state, faculty: event.target.value.split(' ')[0] })} name="selectMulti" id="exampleSelectMulti">

                                        {this.props.facultyList.facultyList.map((faculty, idx) => <option key={idx}>{idx + ' ' + faculty.fname}</option>)}


                                    </Input>
                                </Col>
                            </FormGroup>

                            <Button type="submit" size="sm" color="primary"  ><i className="fa fa-dot-circle-o"></i> Register</Button>


                        </Form>

                    </CardBody>
                </Card>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        facultyList: state.adminfaculty,
    }
}

const actionCreators = {
    getfaculty: getFacultyList,
}

export default connect(mapStateToProps, actionCreators)(AddSection);